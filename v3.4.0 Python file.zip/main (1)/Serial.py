#!/usr/bin/env python2
# -*- coding: utf-8 -*-
#JimmyChen V3.0 by MackaJunest COPYRIGHT 2022
'''
                            front
                   leg  leg1|    |leg2
    4 groups: 1,2  -|1      |    |
              3,4  -|2_____Jimmychen
              5,6  -|3      |    |
              7,8  -|4  leg4|    |leg3
                             back
'''
import serial
import time as t

global ser

print("JimmyChen V3.0 by MackaJunest COPYRIGHT 2022")
try:
    ser=serial.Serial('/dev/ttyUSB0',115200,timeout=1)
    print("Connected!")
    t.sleep(0.5)
    print("Port:/dev/ttyUSB0")
    t.sleep(0.2)
    print("Baudrate:115200")
    t.sleep(0.5)
    print("Starting quadruped...")
except:
    ser=serial.Serial('/dev/ttyUSB1',115200,timeout=1)
    print("Connected!")
    t.sleep(0.5)
    print("Port:/dev/ttyUSB1")
    t.sleep(0.2)
    print("Baudrate:115200")
    t.sleep(0.5)
    print("Starting quadruped...")

def senddata(data):
#    ser.write(str.encode(h1+','+s1+','+h2+','+s2+','+h3+','+s3+','+h4+','+s4','+x+','+y))
    ser.write(data)