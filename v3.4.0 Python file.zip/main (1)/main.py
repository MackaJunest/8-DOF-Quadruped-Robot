#!/usr/bin/env python
# -*- coding: utf-8 -*-

#JimmyChen V3.0 by MackaJunest COPYRIGHT 2022
'''
                            front
                   leg  leg1|    |leg2
    4 groups: 1,2  -|1      |    |
              3,4  -|2_____Jimmychen
              5,6  -|3      |    |
              7,8  -|4  leg3|    |leg4
                             back
'''

import threading
import motion
import display as dp
import cam
import controller as ctrl
import Serial


motion.set_function(1,50,100,15,-230)
motion.set_function(2,50,100,15,-230)
motion.set_function(3,50,100,15,-230)
motion.set_function(4,50,100,15,-230)

cam=0
x=90
y=90
data =[35,100,35,100,35,100,35,100,45,45]
def thread1():
    global x
    global y
    global data
    while True:
        ctrl.controller()
        '''
        if ctrl.val[1]<0.5 and ctrl.val[1]>-0.5 and hpg==1:
            if ctrl.val[3]>0.5:
                x+=1
            if ctrl.val[3]<-0.5:
                x-=1
            data[8]=x
            
            data[9]=y
            data_string = ",".join([str(i) for i in data])
            Serial.senddata(str.encode(data_string))
        '''
        if ctrl.val[1]>0.5 or ctrl.val[1]<-0.5 or ctrl.val[0]>0.5 or ctrl.val[0]<-0.5:
            if ctrl.val[1]>0.5:
                motion.trotbackward(5)
            if ctrl.val[1]<-0.5:
                motion.trotforward(5)
            if ctrl.val[0]>0.5:
                motion.trotturnright(5)
            if ctrl.val[0]<-0.5:
                motion.trotturnleft(5)
            if ctrl.val[3]>0.5:
                x-=3
                if x<=0:
                    x+=3
            if ctrl.val[3]<-0.5:
                x+=3
                if x>=180:
                    x-=3
            if ctrl.val[4]>0.5:
                y+=3
                if y>=180:
                    y-=3
            if ctrl.val[4]<-0.5:
                y-=3
                if y<=0:
                    y+=3
            data = [motion.data[0], motion.data[1], motion.data[2], motion.data[3], motion.data[4], motion.data[5], motion.data[6], motion.data[7], x, y]
            data_string = ",".join([str(i) for i in data])
            Serial.senddata(str.encode(data_string))

def thread2():
    while cam:
        cam.FD()

    t2 = threading.Thread(target=thread2)
    t2.start()
def main():
    t1 = threading.Thread(target=thread1)
    t1.start()
if __name__=='__main__':
    main()
dp.display_1()

