#!/usr/bin/env python2
# -*- coding: utf-8 -*-
#JimmyChen V3.0 by MackaJunest COPYRIGHT 2022
'''
                            front
                   leg  leg1|    |leg2
    4 groups: 1,2  -|1      |    |
              3,4  -|2_____Jimmychen
              5,6  -|3      |    |
              7,8  -|4  leg4|    |leg3
                             back
'''
import kinematics as km
import math
import time

hp1=0
hp2=0
hp3=0
hp4=0

x1=0
x2=0
x3=0
x4=0


sp1=0
sp2=0
sp3=0
sp4=0

sy1=0
sy2=0
sy3=0
sy4=0

data=[0,0,0,0,0,0,0,0,0,0]

#set_function(1,55,90,-10,-200)
def set_function(leg,Hei,SLen,Hshift,Vshift): #(leg NO., height(cm), steplength(cm),Horizontal Shift(cm), Vertical Shift(cm))

    global sp1
    global sp2
    global sp3
    global sp4
    global xmax1
    global xmax2
    global xmax3
    global xmax4
    global x1
    global x2
    global x3
    global x4
    global sy1
    global sy2
    global sy3
    global sy4
    global A1
    global B1
    global C1
    global D1
    global A2
    global B2
    global C2
    global D2
    global A3
    global B3
    global C3
    global D3
    global A4
    global B4
    global C4
    global D4
    
    if leg== 1:
        A1=Hei
        B1=(2*math.pi)/(SLen*2)
        C1=Hshift
        D1=Vshift
        sp1=C1
        xmax1=C1+SLen
        x1=xmax1
        sy1=D1

    
    elif leg== 2:
        A2=Hei
        B2=(2*math.pi)/(SLen*2)
        C2=Hshift
        D2=Vshift
        sp2=C2
        xmax2=C2+SLen
        x2=sp2
        sy2=D2
    
    elif leg== 3:
        A3=Hei
        B3=(2*math.pi)/(SLen*2)
        C3=Hshift
        D3=Vshift
        sp3=C3
        xmax3=C3+SLen
        x3=xmax3
        sy3=D3

    elif leg== 4:
        A4=Hei
        B4=(2*math.pi)/(SLen*2)
        C4=Hshift
        D4=Vshift
        sp4=C4
        xmax4=C4+SLen
        x4=sp4
        sy4=D4

def calc(leg,x):
    global ans
    if leg == 1:
        ans=A1*math.sin(B1*(x-C1))+D1
    elif leg == 2:
        ans=A2*math.sin(B2*(x-C2))+D2
    elif leg == 3:
        ans=A3*math.sin(B3*(x-C3))+D3
    elif leg == 4:
        ans=A4*math.sin(B4*(x-C4))+D4

def trotbackward(speed):
    global x1
    global x2
    global x3
    global x4
    global hp1
    global hp2
    global hp3
    global hp4
    global data
    
#leg1
#   set_function(1,50,60,10,-200)
    if x1<=xmax1 and hp1 == 0 :
        calc(1,x1)
        km.Angle1_calc(x1,ans)
        s1= str(int(round(km.leg1_shank)))
        h1= str(int(round(km.leg1_ham)))
        x1+=3
        if x1 >xmax1:
            hp1=1
    
    if x1>=sp1 and hp1 == 1:
        y=sy1
        km.Angle1_calc(x1,y)
        s1= str(int(round(km.leg1_shank)))
        h1= str(int(round(km.leg1_ham)))
        x1-=3
        if x1 <sp1:
            hp1=0

#leg2
#   set_function(2,50,60,10,-200)
    if x2<=xmax2 and hp2 == 0 :
        calc(2,x2)
        km.Angle2_calc(x2,ans)
        s2= str(int(round(km.leg2_shank)))
        h2= str(int(round(km.leg2_ham)))
        x2+=3
        
        if x2 >xmax2:
            hp2=1
    
    if x2>=sp2 and hp2 == 1:
        y=sy2
        km.Angle2_calc(x2,y)
        s2= str(int(round(km.leg2_shank)))
        h2= str(int(round(km.leg2_ham)))
        x2-=3
        if x2 <sp2:
            hp2=0

#leg3
#   set_function(3,50,60,10,-200)
    if x3<=xmax3 and hp3 == 0 :
        calc(3,x3)
        km.Angle3_calc(x3,ans)
        s3= str(int(round(km.leg3_shank)))
        h3= str(int(round(km.leg3_ham)))
        x3+=3
        
        if x3 >xmax3:
            hp3=1
    
    if x3>=sp3 and hp3 == 1:
        y=sy3
        km.Angle3_calc(x3,y)
        s3= str(int(round(km.leg3_shank)))
        h3= str(int(round(km.leg3_ham)))
        x3-=3
        if x3 <sp3:
            hp3=0

#leg4
#   set_function(4,50,60,10,-200)
    if x4<=xmax4 and hp4 == 0 :
        calc(4,x4)
        km.Angle4_calc(x4,ans)
        s4= str(int(round(km.leg4_shank)))
        h4= str(int(round(km.leg4_ham)))
        x4+=3
        if x4 >xmax4:
            hp4=1
    
    if x4>=sp4 and hp4 == 1:
        y=sy4
        km.Angle4_calc(x4,y)
        s4= str(int(round(km.leg4_shank)))
        h4= str(int(round(km.leg4_ham)))
        x4-=3
        if x4 <sp4:
            hp4=0
    data=[h1,s1,h2,s2,h3,s3,h4,s4]
    time.sleep(0.1/(speed+0.01))

def trotforward(speed):
    global x1
    global x2
    global x3
    global x4
    global hp1
    global hp2
    global hp3
    global hp4
    global data
    
#leg1
#   set_function(1,50,60,10,-200)
    if x1<=xmax1 and hp1 == 0 :
        y=sy1
        km.Angle1_calc(x1,y)
        s1= str(int(round(km.leg1_shank)))
        h1= str(int(round(km.leg1_ham)))
        x1+=3
        if x1 >xmax1:
            hp1=1
    
    if x1>=sp1 and hp1 == 1:
        calc(1,x1)
        km.Angle1_calc(x1,ans)
        s1= str(int(round(km.leg1_shank)))
        h1= str(int(round(km.leg1_ham)))
        x1-=3
        if x1 <sp1:
            hp1=0

#leg2
#   set_function(2,50,60,10,-200)
    if x2<=xmax2 and hp2 == 0 :
        y=sy2
        km.Angle2_calc(x2,y)
        s2= str(int(round(km.leg2_shank)))
        h2= str(int(round(km.leg2_ham)))
        x2+=3
        
        if x2 >xmax2:
            hp2=1
    
    if x2>=sp2 and hp2 == 1:
        calc(2,x2)
        km.Angle2_calc(x2,ans)
        s2= str(int(round(km.leg2_shank)))
        h2= str(int(round(km.leg2_ham)))
        x2-=3
        if x2 <sp2:
            hp2=0

#leg3
#   set_function(3,50,60,10,-200)
    if x3<=xmax3 and hp3 == 0 :
        y=sy3
        km.Angle3_calc(x3,y)
        s3= str(int(round(km.leg3_shank)))
        h3= str(int(round(km.leg3_ham)))
        x3+=3
        
        if x3 >xmax3:
            hp3=1
    
    if x3>=sp3 and hp3 == 1:
        calc(3,x3)
        km.Angle3_calc(x3,ans)
        s3= str(int(round(km.leg3_shank)))
        h3= str(int(round(km.leg3_ham)))
        x3-=3
        if x3 <sp3:
            hp3=0

#leg4
#   set_function(4,50,60,10,-200)
    if x4<=xmax4 and hp4 == 0 :
        y=sy4
        km.Angle4_calc(x4,y)
        s4= str(int(round(km.leg4_shank)))
        h4= str(int(round(km.leg4_ham)))
        x4+=3
        if x4 >xmax4:
            hp4=1
    
    if x4>=sp4 and hp4 == 1:
        calc(4,x4)
        km.Angle4_calc(x4,ans)
        s4= str(int(round(km.leg4_shank)))
        h4= str(int(round(km.leg4_ham)))
        x4-=3
        if x4 <sp4:
            hp4=0
    data=[h1,s1,h2,s2,h3,s3,h4,s4]
    time.sleep(0.1/(speed+0.01))

def trotturnleft(speed):
    global x1
    global x2
    global x3
    global x4
    global hp1
    global hp2
    global hp3
    global hp4
    global data
    
#leg1
#   set_function(1,50,60,10,-200)
    if x1<=xmax1 and hp1 == 0 :
        calc(1,x1)
        km.Angle1_calc(x1,ans)
        s1= str(int(round(km.leg1_shank)))
        h1= str(int(round(km.leg1_ham)))
        x1+=3
        if x1 >xmax1:
            hp1=1
    
    if x1>=sp1 and hp1 == 1:
        y=sy1
        km.Angle1_calc(x1,y)
        s1= str(int(round(km.leg1_shank)))
        h1= str(int(round(km.leg1_ham)))
        x1-=3
        if x1 <sp1:
            hp1=0

#leg2
#   set_function(2,50,60,10,-200)
    if x2<=xmax2 and hp2 == 0 :
        y=sy2
        km.Angle2_calc(x2,y)
        s2= str(int(round(km.leg2_shank)))
        h2= str(int(round(km.leg2_ham)))
        x2+=3
        
        if x2 >xmax2:
            hp2=1
    
    if x2>=sp2 and hp2 == 1:
        calc(2,x2)
        km.Angle2_calc(x2,ans)
        s2= str(int(round(km.leg2_shank)))
        h2= str(int(round(km.leg2_ham)))
        x2-=3
        if x2 <sp2:
            hp2=0

#leg3
#   set_function(3,50,60,10,-200)
    if x3<=xmax3 and hp3 == 0 :
        y=sy3
        km.Angle3_calc(x3,y)
        s3= str(int(round(km.leg3_shank)))
        h3= str(int(round(km.leg3_ham)))
        x3+=3
        
        if x3 >xmax3:
            hp3=1
    
    if x3>=sp3 and hp3 == 1:
        calc(3,x3)
        km.Angle3_calc(x3,ans)

        s3= str(int(round(km.leg3_shank)))
        h3= str(int(round(km.leg3_ham)))
        x3-=3
        if x3 <sp3:
            hp3=0

#leg4
#   set_function(4,50,60,10,-200)
    if x4<=xmax4 and hp4 == 0 :
        calc(4,x4)
        km.Angle4_calc(x4,ans)
        s4= str(int(round(km.leg4_shank)))
        h4= str(int(round(km.leg4_ham)))
        x4+=3
        if x4 >xmax4:
            hp4=1
    
    if x4>=sp4 and hp4 == 1:
        y=sy4
        km.Angle4_calc(x4,y)
        s4= str(int(round(km.leg4_shank)))
        h4= str(int(round(km.leg4_ham)))
        x4-=3
        if x4 <sp4:
            hp4=0
    data=[h1,s1,h2,s2,h3,s3,h4,s4]
    time.sleep(0.1/(speed+0.01))

def trotturnright(speed):
    global x1
    global x2
    global x3
    global x4
    global hp1
    global hp2
    global hp3
    global hp4
    global data
    
#leg1
#   set_function(1,50,60,10,-200)
    if x1<=xmax1 and hp1 == 0 :
        calc(1,x1)
        km.Angle1_calc(x1,ans)
        s1= str(int(round(km.leg1_shank)))
        h1= str(int(round(km.leg1_ham)))
        x1+=3
        if x1 >xmax1:
            hp1=1
    
    if x1>=sp1 and hp1 == 1:
        y=sy1
        km.Angle1_calc(x1,y)
        s1= str(int(round(km.leg1_shank)))
        h1= str(int(round(km.leg1_ham)))
        x1-=3
        if x1 <sp1:
            hp1=0

#leg2
#   set_function(2,50,60,10,-200)
    if x2<=xmax2 and hp2 == 0 :
        y=sy2
        km.Angle2_calc(x2,y)
        s2= str(int(round(km.leg2_shank)))
        h2= str(int(round(km.leg2_ham)))
        x2+=3
        
        if x2 >xmax2:
            hp2=1
    
    if x2>=sp2 and hp2 == 1:
        calc(2,x2)
        km.Angle2_calc(x2,ans)
        s2= str(int(round(km.leg2_shank)))
        h2= str(int(round(km.leg2_ham)))
        x2-=3
        if x2 <sp2:
            hp2=0

#leg3
#   set_function(3,50,60,10,-200)
    if x3<=xmax3 and hp3 == 0 :
        y=sy3
        km.Angle3_calc(x3,y)
        s3= str(int(round(km.leg3_shank)))
        h3= str(int(round(km.leg3_ham)))
        x3+=3
        
        if x3 >xmax3:
            hp3=1
    
    if x3>=sp3 and hp3 == 1:
        calc(3,x3)
        km.Angle3_calc(x3,ans)
        s3= str(int(round(km.leg3_shank)))
        h3= str(int(round(km.leg3_ham)))
        x3-=3
        if x3 <sp3:
            hp3=0

#leg4
#   set_function(4,50,60,10,-200)
    if x4<=xmax4 and hp4 == 0 :
        calc(4,x4)
        km.Angle4_calc(x4,ans)
        s4= str(int(round(km.leg4_shank)))
        h4= str(int(round(km.leg4_ham)))
        x4+=3
        if x4 >xmax4:
            hp4=1
    
    if x4>=sp4 and hp4 == 1:
        y=sy4
        km.Angle4_calc(x4,y)
        s4= str(int(round(km.leg4_shank)))
        h4= str(int(round(km.leg4_ham)))
        x4-=3
        if x4 <sp4:
            hp4=0
    data=[h1,s1,h2,s2,h3,s3,h4,s4]
    time.sleep(0.1/(speed+0.01))
